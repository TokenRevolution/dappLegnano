# Getting Started

1. Open project in terminal and run `yarn`
2. Once install is finish run `yarn start` to run locally
3. Open your browser and it should be hosted on `localhost:8080/`

To enable Algolia DocSearch locally, run `cp .env-template .env` and populate
the fields with the correct values.
