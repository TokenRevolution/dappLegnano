module.exports = [
  {
    text: 'Guide',
    link: '/guide/',
  },
]
